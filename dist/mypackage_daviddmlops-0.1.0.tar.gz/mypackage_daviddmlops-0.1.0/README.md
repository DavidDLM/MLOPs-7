# My Package

Este es un paquete de ejemplo en Python para mostrar cómo empaquetar proyectos